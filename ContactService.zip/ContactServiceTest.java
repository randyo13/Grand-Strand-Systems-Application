package contacts.test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import contact.Contact;
import contact.ContactService;

import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("2487548438", "Pablo", "Escobar", "2487548438", "10 Sprint Street");
        contactService.addContact(contact);

        Contact fetchedContact = contactService.getContact("2487548438");
        assertNotNull(fetchedContact);
    }

    @Test
    public void testAddDuplicateContact() {
        Contact contact = new Contact("2487548438", "Pablo", "Escobar", "2487548438", "10 Sprint Street");
        contactService.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> contactService.addContact(contact));
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("2487548438", "Pablo", "Escobar", "2487548438", "10 Sprint Street");
        contactService.addContact(contact);
        contactService.deleteContact("2487548438");

        assertNull(contactService.getContact("2487548438"));
    }

    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("2487548438", "Pablo", "Escobar", "2487548438", "10 Sprint Street");
        contactService.addContact(contact);
        contactService.updateContact("2487548438", "Edwin", "Jiminez", "5709059393", "60 Burn Blvd");

        Contact updatedContact = contactService.getContact("2487548438");
        assertEquals("Edwin", updatedContact.getFirstName());
        assertEquals("Jiminez", updatedContact.getLastName());
        assertEquals("5709059393", updatedContact.getPhone());
        assertEquals("60 Burn Blvd", updatedContact.getAddress());
    }
}

