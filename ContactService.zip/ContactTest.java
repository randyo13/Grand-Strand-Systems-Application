package contacts.test;

import org.junit.jupiter.api.Test;

import contact.Contact;

import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {
    @Test
    public void testContactCreation() {
        Contact contact = new Contact("1234567890", "Pablo", "Escobar", "1234567890", "12355 Street");

        assertEquals("1234567890", contact.getContactId());
        assertEquals("Pablo", contact.getFirstName());
        assertEquals("Escobar", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("12355 Street", contact.getAddress());
    }

    @Test
    public void testInvalidContactCreation() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Pablo", "Escobar", "1234567890", "12355 Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "MadeUp", "Name", "123432214", "123567777764 Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", null, "Doeskiwoeskiesmi", "12342453252322", "Spring Street"));
    }
}
